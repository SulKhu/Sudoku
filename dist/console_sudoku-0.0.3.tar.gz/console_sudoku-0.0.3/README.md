This is a command-line version of the classic game Sudoku.

Instructions:
...
