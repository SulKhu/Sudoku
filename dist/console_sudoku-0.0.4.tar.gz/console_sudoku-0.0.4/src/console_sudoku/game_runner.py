from sudoku_runner import SudokuRunner

def run():
    r = SudokuRunner()
    r.run_game()