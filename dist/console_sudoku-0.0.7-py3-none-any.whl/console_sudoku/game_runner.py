from console_sudoku import sudoku_runner
from sudoku_runner import SudokuRunner

def run():
    r = SudokuRunner()
    r.run_game()