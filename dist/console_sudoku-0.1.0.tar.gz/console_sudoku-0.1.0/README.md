This is a command-line version of the classic game Sudoku. Make sure your have Python 3.12 installed

To start a game of sudoku after installing console_sudoku, run a python shell and type: "from console_sudoku import game". Then, simply type: "game.run()" and then follow the instructions of the game!

To play the game of sudoku, make sure to copy the puzzle exactly and return the exact same puzzle with the spaces replaced with numbers to not throw an exception.

Have fun!




